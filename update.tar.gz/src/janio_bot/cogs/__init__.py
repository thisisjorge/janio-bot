"""Discord command groups."""
